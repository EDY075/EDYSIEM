# EDY SIEM — Problemas de UI/UX percebidos (auditoria inicial)

> **Aviso de transparência:** este ambiente não tem visão de imagens. A lista abaixo
> foi levantada a partir da **estrutura do código/design system** e das telas reais
> (seed `/soc`), e deve ser **confirmada no olhar das imagens** em `UX_REVIEW/screenshots`.
> Nada foi corrigido.

1. **Cobertura incompleta da auditoria** — drawer, filtros, abas (Simulator/IOC/Assets),
   empty state, skeleton e toast não são alcançáveis por URL; precisam de captura com
   interação (faltam nesta rodada).

2. **Contraste de texto secundário** — `textMuted`/`textSecondary` em `fontSize: xs`
   sobre `surface` tende a ficar fraco no tema dark (leitura de rótulos/labels). Confirmar
   nas capturas (03, 04, 05).

3. **KPIs "decorativos"** — o sparkline dos `KpiCard` é determinístico (seed estável),
   o que deixa os 6 cards do Dashboard com forma visualmente idêntica (01). Pedir um
   trecho real/séries por card.

4. **Tabelas com `—`** — cells de owner/user ausentes mostram "—" (04, 05): aumenta o
   ruído; sugerir EmptyCell mais discreto. Cabeçalhos sem sticky ao rolar.

5. **Responsivo 768 (tablet)** — sidebar colapsa, mas grids (Dashboard/War Room) só
   colapsam com `@media <1280`; em 768 há empilhamento longo (10). Avaliar breakpoints.

6. **Empty states inconsistentes** — alguns painéis repetem "Sem dados no período" com
   estilos diversos (War Room MITRE/IOC, Investigation). Unificar os padrões de vazio
   com ação de retry onde houver falha.

7. **Detection Dashboard** (08) — cards simcam "Mini" repetem o mesmo bloco; gráficos de
   barra com eixos técnicos podem não ter legendas; confirmar hierarquia visual.

## Próximo passo
Sprint forte de **UI/UX Polish** com base na análise das imagens.